if ball.xcor() < -380:
    #     ball.reset_position()